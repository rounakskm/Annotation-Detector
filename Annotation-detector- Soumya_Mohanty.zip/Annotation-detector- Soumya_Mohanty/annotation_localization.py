#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 23:55:49 2018

@author: Soumya
"""

# Importing Libraries

import os
import torch
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader


import torch.nn as nn
import torch.nn.functional as F


from torch.autograd import Variable

# Creating the dataloader
class ImgDataset(Dataset):
    def __init__(self, data_dir, transform = None, 
                 img_shape = (600,600), grid_dim = (30,30)):
        
        # Length of per grid vector, based on number of classes being detected
        self.vector_len = 5 
        
        self.img_shape = img_shape
        self.grid_dim = grid_dim
        self.transform = transform
        
        
        # Create a grid. Grid doesnt change as image size is same
        self.grid_list, self.col_width, self.row_height = \
        self.create_grid(self.img_shape, self.grid_dim)
        
        # Fetch all files from dataset directory
        self.files = os.listdir(data_dir)
        self.files = [os.path.join(data_dir,f) for f in self.files]

        # Make separate list for images and text files
        self.img_list = [f for f in self.files if '.jpg' in f]
        self.txt_list = [f for f in self.files if '.txt' in f]
        self.labels = []
        
        for txt_file in self.txt_list:
            # Call function to iterate over grid_list 
            # and generate label vector for the image
            img_label = self.label_vector_gen(txt_file)
            # Has one-to-one correspondence with img_list
            self.labels.append(img_label) 
        

    def __len__(self):
        '''Return size of the dataset'''
        return len(self.img_list)
    
    def __getitem__(self,idx):
        '''Enable indexing on dataset'''
        # Processing the image
        img = Image.open(self.img_list[idx]).convert('RGB')  # PIL image
        image = self.transform(img)
        
        # Processing the label for that corresponding image
        label = self.labels[idx]
        label = torch.FloatTensor(label)
        label = label.view(-1)
        return image, label

    def create_grid(self,img_shape,grid_dim):
        '''
        Function: 
            Function creates a grid with cells of equal size.
        
        Parameters:
            img_shape : dimensions of the image (height,width).
            grid_dim  : dimensions of the grid (rows,colms).
            Note: width must be divisible by no. of columns
            and height must be divisible by no. of rows
            
        Returns:
            This function returns a list of top left coordinates of cells, 
            along with the col_width and row_height.
        '''
        height, width = img_shape
        rows,colms = grid_dim
        
        col_width = width//colms
        
        row_height = height//rows
        
        grid_list = []
        
        for c in range(0,width,col_width): # Step size is the col_width
            for r in range(0,height,row_height): # Step size is the row_height
                grid_list.append((c,r))
                
        return grid_list, col_width, row_height


    def label_vector_gen(self,txt_file):
        '''
        Function: 
            Function generates the label vector for each image.
        
        Parameters:
            txt_file  : Name of file name that has the bounding box data.
        Returns:
            This function returns the label vector for each image.
            Note: Each label is of size
            grid_rows x grid_colmn x no.of classes x len of vector
            = len(grid_list) x 1 x 5
        '''
        
        # Open file to read box details
        with open(txt_file, 'r') as file:
            bounding_boxes = file.read().split('\n')
            # Remove last emelent as it is empty
            bounding_boxes = bounding_boxes[:-1]
        
        coordinate_list = [] # Store coordinates of cells with bbox center 
        label = [] # Store the labels for each bounding box
        
        if len(bounding_boxes)>0:
            for box in bounding_boxes:
                box = box.split(' ')
                # Each element of box list has one attribute of the box as str
                # un-normalize them by multiplying width and height
                box_center_x = float(box[1]) * self.img_shape[1]
                box_center_y = float(box[2]) * self.img_shape[0]
                
                # Get the coordinate of the cell containing the box centers
                grid_x = (box_center_x//self.col_width) * self.col_width
                grid_y = (box_center_y//self.row_height) * self.row_height
                coordinate_list.append((grid_x,grid_y))
                
                
            # Check if point lies in cell and generate the vector
            for cell in self.grid_list:
                if cell in coordinate_list:
                    # Make vector as required
                    idx = coordinate_list.index(cell)
                    box_info = bounding_boxes[idx] # Get corresponding box data
                    box_info = box_info.split(' ')
                    
                    class_pred = float(box_info[0]) 
                    x_center = float(box_info[1])
                    y_center = float(box_info[2])
                    width = float(box_info[3])
                    height = float(box_info[4])
                    
                    label.append((class_pred, 
                                  x_center, 
                                  y_center, 
                                  width, 
                                  height))
                else:
                    # 99 means no value as object doesnt exist in the grid
                    # (class_pred, x_center, y_center, width, height)
                    label.append((99,99,99,99,99))
                    
        elif len(bounding_boxes) == 0:
            label = [(99,99,99,99,99)] * (self.grid_dim[0] * self.grid_dim[1])
            
        return label
    

# Normalizing and loading the data
        
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                 std=[0.229, 0.224, 0.225])

transform = transforms.Compose([transforms.Resize((600,600)),
                                transforms.ToTensor(),
                                normalize])

# As the center, width and height are normalized,
# We can resize the images and use the new img_shape to get the desired box      
train_dataset = ImgDataset('dataset_train', transform = transform, 
                 img_shape = (600,600), grid_dim = (30,30))

train_dataloader = DataLoader(train_dataset,
                              batch_size=4, 
                              shuffle=True,
                              num_workers=0)
        
            
            


# Model and train

# Create Convolutional Neural Net to detect and localize annotations
# Net should take an image as input and give out a vector equivalent 
# to the label vector as output.
# Input image shape (h=600,w=600,c=3) in batch: 4x3x600x300

# Net should give 900x5 output as of now
# As a 60x30 grid with 5 features per cell = 900x5
# Input batch will have size batch_size x 900x5

# Using YOLO like architecture
# 9 convolutoion layers and one fully connected layer
# Kernel for convolution = 3x3, stride = 1
# Kernel for MaxPooling = 2x2, stride = 2

class CNN(nn.Module):
  
  def __init__(self):
    super(CNN,self).__init__()
    
    # Convolution layer 1
    # Out channels is the number of filters
    self.conv1 = nn.Conv2d(in_channels=3, out_channels=16,
                           kernel_size=3, padding =1)
    self.bn1 = nn.BatchNorm2d(16)
    
    # Convolution layer 2
    self.conv2 = nn.Conv2d(in_channels=16, out_channels=32,
                           kernel_size=3, padding =1)
    self.bn2 = nn.BatchNorm2d(32)
    
    # Convolution layer 3
    self.conv3 = nn.Conv2d(in_channels=32, out_channels=64,
                           kernel_size=3, padding =1)
    self.bn3 = nn.BatchNorm2d(64)
    
    # Convolution layer 4
    self.conv4 = nn.Conv2d(in_channels=64, out_channels=128,
                           kernel_size=3, padding =1)
    self.bn4 = nn.BatchNorm2d(128)
    
    # Convolution layer 5
    self.conv5 = nn.Conv2d(in_channels=128, out_channels=256,
                           kernel_size=3, padding =1)
    self.bn5 = nn.BatchNorm2d(256)
    
    # Convolution layer 6
    self.conv6 = nn.Conv2d(in_channels=256, out_channels=512,
                           kernel_size=3, padding =1)
    self.bn6 = nn.BatchNorm2d(512)
    
    # Convolution layer 7
    self.conv7 = nn.Conv2d(in_channels=512, out_channels=1024,
                           kernel_size=3, padding =1)
    self.bn7 = nn.BatchNorm2d(1024)
    
    # Convolution layer 8
    self.conv8 = nn.Conv2d(in_channels=1024, out_channels=1024,
                           kernel_size=3, padding =1)
    self.bn8 = nn.BatchNorm2d(1024)
    
    # Convolution layer 9
    self.conv9 = nn.Conv2d(in_channels=1024, out_channels=1024,
                           kernel_size=3, padding =1)
    
    
    # Output size should be:
    # grid_dim X 5
    # 30x30 x 5 = 900X5 as generated labels are 900x5
    
    
    
    # Fully connected Layer, Increase number of in features, fix out features
    self.fc1 = nn.Linear(in_features=82944, out_features=30*30*5)
    
    # Now we get 
    
  def forward(self,x):
    print(x.size())
    x= self.bn1(self.conv1(x))
    print(x.size())
    x= F.max_pool2d(x,kernel_size=2,stride=2)
    print(x.size())
    x= F.leaky_relu(x,inplace=False)
    
    x= self.bn2(self.conv2(x))
    print(x.size())
    x= F.max_pool2d(x,kernel_size=2,stride=2)
    print(x.size())
    x= F.leaky_relu(x,inplace=False)
    
    x= self.bn3(self.conv3(x))
    print(x.size())
    x= F.max_pool2d(x,kernel_size=2,stride=2)
    print(x.size())
    x= F.leaky_relu(x,inplace=False)
    
    x= self.bn4(self.conv4(x))
    print(x.size())
    x= F.max_pool2d(x,kernel_size=2,stride=2)
    print(x.size())
    x= F.leaky_relu(x,inplace=False)
    
    x= self.bn5(self.conv5(x))
    print(x.size())
    x= F.max_pool2d(x,kernel_size=2,stride=2)
    print(x.size())
    x= F.leaky_relu(x,inplace=False)
    
    x= self.bn6(self.conv6(x))
    print(x.size())
    x= F.max_pool2d(x,kernel_size=2,stride=2)
    print(x.size())
    x= F.leaky_relu(x,inplace=False)
    
    
    x= self.bn7(self.conv7(x))
    print(x.size())
    x= self.bn8(self.conv8(x))
    print(x.size())
    x= self.conv9(x)
    print(x.size())
    # Flattening the output before it hits fully connected layer
    #x = x.view(x.size(0), -1) same as line below
    x= x.view(-1)
    print(x.size()) 
    x= self.fc1(x)
    print(x.size())
    return x
    
    
model = CNN()

model.eval()
    
'''    
# As dataloader has batch_size = 4
# We will get one batch of 4 images with each iteration 
for i, (images_batch, target_batch) in enumerate(train_dataloader):
    # Convert images_batch and target to pytorch Variable
    images_batch, target_batch = Variable(images_batch),Variable(target_batch)
    
      
    out = model(images_batch) # Forward pass
    break

'''
# Passing single input
for i, (image, target) in enumerate(train_dataset):
    # Convert images_batch and target to pytorch Variable
    image, target = Variable(image),Variable(target)
    image = image.unsqueeze(0)
    out = model(image) # Forward pass
    break
            
            