# Annotation Detector

Run find_annotations.py -o < un-annotated image > -a < annotated image>

This will generate the data for training the model

annotation_detector.ipynb is a Jupyter notebook which can be run on Google Colab
and is used to train, save, load and test the model to detect and localize annotations.

  
